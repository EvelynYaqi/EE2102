import numpy as np

#Orthogonal matrix
omat = np.array([[0,1],[-1,0]]) 



